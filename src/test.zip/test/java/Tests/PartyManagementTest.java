package Tests;

import Classes.Heros.*;
import Classes.Party;
import Factory.HeroFactoryProvider;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TC-10 — Party management: hero cap, add/remove, and alive-hero counting.
 *
 * The 5-party cap (per user) is enforced in the database layer; here we
 * test the in-memory party model itself.
 */
public class PartyManagementTest {

    private static final int MAX_HEROES = 5;

    private Party party;

    @BeforeEach
    void setUp() {
        party = new Party("TestParty", "A party for testing", "testUser");
    }

    // ── TC-10: Hero capacity ──────────────────────────────────────────────

    /**
     * TC-10 — Party starts empty; heroes can be added up to the cap.
     */
    @Test
    void tc10_addHeroes_upToMaxCapacity() {
        for (int i = 0; i < MAX_HEROES; i++) {
            party.addHero(HeroFactoryProvider.create(HeroClass.WARRIOR));
        }
        assertEquals(MAX_HEROES, party.getHeroes().size(),
                "Party should hold exactly " + MAX_HEROES + " heroes");
    }

    /**
     * TC-10b — Removing a hero reduces the party size.
     */
    @Test
    void tc10b_removeHero_reducesSize() {
        Warrior w = new Warrior();
        party.addHero(w);
        assertEquals(1, party.getHeroes().size());

        party.removeHero(w);
        assertEquals(0, party.getHeroes().size(),
                "Party should be empty after removing its only hero");
    }

    // ── Alive counting ─────────────────────────────────────────────────────

    /**
     * TC-10c — getAliveCount() returns the number of non-defeated heroes.
     */
    @Test
    void tc10c_aliveCount_correctAfterDefeat() {
        Warrior w1 = new Warrior();
        Warrior w2 = new Warrior();
        Mage    m  = new Mage();
        party.addHero(w1);
        party.addHero(w2);
        party.addHero(m);

        assertEquals(3, party.getAliveCount(), "All 3 heroes should be alive initially");

        w1.takeDamage(9999);
        assertEquals(2, party.getAliveCount(), "Alive count should be 2 after one defeat");

        m.takeDamage(9999);
        assertEquals(1, party.getAliveCount(), "Alive count should be 1 after two defeats");
    }

    /**
     * TC-10d — hasAliveHeroes() returns false when all heroes are defeated.
     */
    @Test
    void tc10d_hasAliveHeroes_falseWhenAllDefeated() {
        Warrior w = new Warrior();
        Mage    m = new Mage();
        party.addHero(w);
        party.addHero(m);

        w.takeDamage(9999);
        m.takeDamage(9999);

        assertFalse(party.hasAliveHeroes(),
                "hasAliveHeroes() must return false when every hero is defeated");
    }

    /**
     * TC-10e — hasAliveHeroes() returns true if any one hero survives.
     */
    @Test
    void tc10e_hasAliveHeroes_trueIfOneAlive() {
        Warrior w1 = new Warrior();
        Warrior w2 = new Warrior();
        party.addHero(w1);
        party.addHero(w2);

        w1.takeDamage(9999);

        assertTrue(party.hasAliveHeroes(),
                "hasAliveHeroes() must return true when at least one hero is alive");
    }

    // ── Party metadata ────────────────────────────────────────────────────

    /**
     * Party name, info, and username are accessible and correct.
     */
    @Test
    void partyMetadata_gettersReturnCorrectValues() {
        assertEquals("TestParty",           party.getPartyName(),
                "getPartyName() should return the name passed to the constructor");
        assertEquals("A party for testing", party.getPartyInfo(),
                "getPartyInfo() should return the info passed to the constructor");
        assertEquals("testUser",            party.getUsername(),
                "getUsername() should return the username passed to the constructor");
    }

    /**
     * Party setters update their respective fields.
     */
    @Test
    void partyMetadata_settersUpdateFields() {
        party.setPartyName("Renamed");
        party.setPartyInfo("New info");
        party.setUsername("newUser");

        assertEquals("Renamed",  party.getPartyName());
        assertEquals("New info", party.getPartyInfo());
        assertEquals("newUser",  party.getUsername());
    }
}
