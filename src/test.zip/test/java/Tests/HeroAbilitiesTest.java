package Tests;

import Classes.Heros.*;
import Classes.Party;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TC-08 — Hero special abilities (Order Protect, Mage Replenish, Chaos Fireball).
 * Also covers the Hero revive mechanic used by the Inn.
 */
public class HeroAbilitiesTest {

    private Order   order;
    private Mage    mage;
    private Warrior warrior;
    private Chaos   chaos;
    private Party   friendlyParty;
    private Party   enemyParty;

    @BeforeEach
    void setUp() {
        order   = new Order();
        mage    = new Mage();
        warrior = new Warrior();
        chaos   = new Chaos();

        friendlyParty = new Party("Friendly", "", "player1");
        friendlyParty.addHero(order);
        friendlyParty.addHero(mage);
        friendlyParty.addHero(warrior);

        enemyParty = new Party("Enemy", "", "player2");
        enemyParty.addHero(chaos);
    }

    // ── TC-08a: Order Protect ─────────────────────────────────────────────

    /**
     * TC-08 — Protect applies a shield equal to 10% maxHp to ALL friendly heroes.
     */
    @Test
    void tc08a_protect_appliesShieldToAllFriendlyHeroes() {
        order.setMana(25); // Exact cost

        int expectedOrderShield   = order.getMaxHp()   / 10;
        int expectedMageShield    = mage.getMaxHp()    / 10;
        int expectedWarriorShield = warrior.getMaxHp() / 10;

        order.useSpecialAbility(null, friendlyParty, enemyParty);

        assertEquals(expectedOrderShield,   order.getShield(),
                "Order should receive a 10% maxHp shield");
        assertEquals(expectedMageShield,    mage.getShield(),
                "Mage should receive a 10% maxHp shield");
        assertEquals(expectedWarriorShield, warrior.getShield(),
                "Warrior should receive a 10% maxHp shield");
    }

    /**
     * TC-08b — Protect deducts 25 mana from Order.
     */
    @Test
    void tc08b_protect_deductsMana() {
        order.setMana(50);
        order.useSpecialAbility(null, friendlyParty, enemyParty);
        assertEquals(25, order.getMana(), "Protect should cost exactly 25 mana");
    }

    /**
     * TC-08c — Shield absorbs incoming damage before HP is reduced.
     */
    @Test
    void tc08c_shield_absorbsDamageBeforeHp() {
        int shieldAmount = 10;
        warrior.addShield(shieldAmount);
        int hpBefore = warrior.getHp();

        // Attack for exactly shield amount — HP should be unchanged
        warrior.takeDamage(shieldAmount);
        // Shield absorbed all, but minimum 1 damage still applies
        assertTrue(warrior.getHp() < hpBefore || warrior.getHp() == hpBefore - 1,
                "Shield should absorb damage; only minimum-1 fallback may reduce HP");
    }

    /**
     * TC-08d — Protect is unavailable when Order has < 25 mana.
     */
    @Test
    void tc08d_protect_unavailableWithInsufficientMana() {
        order.setMana(24);
        assertFalse(order.canUseSpecialAbility(),
                "Protect must be unavailable with < 25 mana");
    }

    // ── Mage Replenish ────────────────────────────────────────────────────

    /**
     * Mage Replenish restores 30 mana to all allies and 60 to self.
     */
    @Test
    void mageReplenish_restoresManaToParty() {
        mage.setMana(80); // Full cost available
        // Drain allies' mana first
        order.setMana(0);
        warrior.setMana(0);

        mage.useSpecialAbility(null, friendlyParty, enemyParty);

        assertEquals(30, order.getMana(),   "Order should gain 30 mana from Replenish");
        assertEquals(30, warrior.getMana(), "Warrior should gain 30 mana from Replenish");
        // Mage spent 80, gains 60 back → net: 0 - 80 + 60 = -20 → but started at 80
        assertEquals(60, mage.getMana(),
                "Mage should net 60 mana (spent 80, received 60 self-regen)");
    }

    // ── Chaos Fireball ────────────────────────────────────────────────────

    /**
     * Chaos Fireball hits up to 3 enemies for 2× attack damage.
     */
    @Test
    void chaosFireball_hitsUpToThreeEnemies() {
        chaos.setMana(30);
        // Set up 3 enemy targets
        Warrior e1 = new Warrior();
        Mage    e2 = new Mage();
        Order   e3 = new Order();
        Party chaosParty  = new Party("ChaosParty", "", "p1");
        chaosParty.addHero(chaos);
        Party targetParty = new Party("Targets", "", "p2");
        targetParty.addHero(e1);
        targetParty.addHero(e2);
        targetParty.addHero(e3);

        int e1HpBefore = e1.getHp();
        int e2HpBefore = e2.getHp();
        int e3HpBefore = e3.getHp();

        chaos.useSpecialAbility(e1, chaosParty, targetParty);

        assertTrue(e1.getHp() < e1HpBefore, "Enemy 1 should take Fireball damage");
        assertTrue(e2.getHp() < e2HpBefore, "Enemy 2 should take Fireball damage");
        assertTrue(e3.getHp() < e3HpBefore, "Enemy 3 should take Fireball damage");
    }

    // ── Hero Revive (Inn mechanic) ─────────────────────────────────────────

    /**
     * Revived hero is no longer defeated and has 50% HP.
     */
    @Test
    void heroRevive_restoresHalfHpAndClearsDefeated() {
        warrior.takeDamage(9999); // Kill warrior
        assertTrue(warrior.isDefeated(), "Warrior should be defeated before revive");

        warrior.revive();

        assertFalse(warrior.isDefeated(),    "Warrior should no longer be defeated after revive");
        assertEquals(warrior.getMaxHp() / 2, warrior.getHp(),
                "Revived hero should have 50% HP");
        assertFalse(warrior.isStunned(),     "Revived hero should not be stunned");
    }

    /**
     * Revive does nothing if the hero is not defeated.
     */
    @Test
    void heroRevive_noEffectOnLivingHero() {
        int hpBefore = warrior.getHp();
        warrior.revive(); // Should be a no-op
        assertEquals(hpBefore, warrior.getHp(),
                "Revive should have no effect on a living hero");
    }
}
