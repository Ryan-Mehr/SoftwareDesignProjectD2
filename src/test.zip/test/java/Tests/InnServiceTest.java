package Tests;

import Classes.Campaign.CampaignState;
import Classes.Heros.Warrior;
import Classes.Heros.Mage;
import Classes.Heros.Hero;
import Classes.Inn.InnService;
import Classes.Inventory.ItemType;
import Classes.Party;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TC-12 — Inn system: hero healing, hero revival, and item shop purchases.
 * All operations are gold-gated and interact with CampaignState.
 */
public class InnServiceTest {

    private InnService    innService;
    private CampaignState state;
    private Warrior       warrior;
    private Mage          mage;
    private Party         party;

    @BeforeEach
    void setUp() {
        warrior = new Warrior();
        mage    = new Mage();

        party = new Party("TestParty", "", "testUser");
        party.addHero(warrior);
        party.addHero(mage);

        state      = new CampaignState("testUser", party);
        innService = new InnService();
    }

    // ── TC-12a: Item purchase — success ──────────────────────────────────

    /**
     * TC-12 — Purchasing a Health Potion (30g) deducts gold and adds to inventory.
     */
    @Test
    void tc12_purchaseHealthPotion_deductsGoldAndAddsToInventory() {
        state.setGold(100);
        String result = innService.purchaseItem(state, ItemType.HEALTH_POTION);

        assertEquals(70, state.getGold(),
                "Gold should decrease by the item cost (30)");
        assertEquals(1, state.getInventory().getQuantity(ItemType.HEALTH_POTION),
                "Inventory should contain 1 Health Potion after purchase");
        assertTrue(result.contains("Purchased"),
                "Result message should confirm the purchase");
    }

    /**
     * TC-12b — Cannot purchase an item when gold is insufficient.
     */
    @Test
    void tc12b_purchaseItem_insufficientGold_doesNotBuy() {
        state.setGold(10); // Health Potion costs 30
        String result = innService.purchaseItem(state, ItemType.HEALTH_POTION);

        assertEquals(10, state.getGold(),
                "Gold should not change when purchase fails");
        assertEquals(0, state.getInventory().getQuantity(ItemType.HEALTH_POTION),
                "Inventory should remain empty when purchase fails");
        assertTrue(result.contains("Not enough gold"),
                "Result message should indicate insufficient gold");
    }

    /**
     * TC-12c — Multiple purchases of the same item stack in inventory.
     */
    @Test
    void tc12c_purchaseItem_stacksCorrectly() {
        state.setGold(200);
        innService.purchaseItem(state, ItemType.HEALTH_POTION);
        innService.purchaseItem(state, ItemType.HEALTH_POTION);

        assertEquals(2, state.getInventory().getQuantity(ItemType.HEALTH_POTION),
                "Purchasing the same item twice should stack to quantity 2");
        assertEquals(140, state.getGold(), "Gold should decrease by 60 after two 30g purchases");
    }

    // ── Inn healing ───────────────────────────────────────────────────────

    /**
     * Inn: healing a living hero restores full HP and costs 20 gold.
     */
    @Test
    void innHeal_restoresHpAndDeductsGold() {
        state.setGold(50);
        warrior.setHp(10); // Damage warrior first
        int goldBefore = state.getGold();

        String result = innService.healHero(state, warrior);

        assertEquals(warrior.getMaxHp(), warrior.getHp(),
                "Fully healed hero should have maxHp");
        assertEquals(goldBefore - 20, state.getGold(),
                "Healing should cost 20 gold");
        assertTrue(result.contains("healed"), "Result should confirm healing");
    }

    /**
     * Inn: cannot heal when gold is insufficient.
     */
    @Test
    void innHeal_insufficientGold_doesNotHeal() {
        state.setGold(10); // Need 20
        warrior.setHp(50);

        innService.healHero(state, warrior);

        assertEquals(50, warrior.getHp(),
                "HP should not change when heal fails due to insufficient gold");
        assertEquals(10, state.getGold(), "Gold should not change when heal fails");
    }

    /**
     * Inn: cannot use Heal on a defeated hero — must use Revive.
     */
    @Test
    void innHeal_onDefeatedHero_returnsError() {
        state.setGold(100);
        warrior.takeDamage(9999);
        assertTrue(warrior.isDefeated());

        String result = innService.healHero(state, warrior);

        assertTrue(result.contains("defeated"),
                "Heal on a defeated hero should return an error message");
        assertTrue(warrior.isDefeated(),
                "Warrior should remain defeated — Heal cannot revive");
    }

    // ── Inn revival ───────────────────────────────────────────────────────

    /**
     * Inn: reviving a defeated hero costs 50 gold and restores 50% HP.
     */
    @Test
    void innRevive_revivedHeroHasHalfHp() {
        state.setGold(100);
        mage.takeDamage(9999);
        assertTrue(mage.isDefeated());

        String result = innService.reviveHero(state, mage);

        assertFalse(mage.isDefeated(),       "Mage should no longer be defeated");
        assertEquals(mage.getMaxHp() / 2, mage.getHp(), "Revived hero should have 50% HP");
        assertEquals(50, state.getGold(),    "Revival should cost 50 gold");
        assertTrue(result.contains("revived"), "Result should confirm revival");
    }

    /**
     * Inn: cannot revive when gold is insufficient.
     */
    @Test
    void innRevive_insufficientGold_doesNotRevive() {
        state.setGold(20); // Need 50
        mage.takeDamage(9999);

        innService.reviveHero(state, mage);

        assertTrue(mage.isDefeated(), "Mage should remain defeated when revival fails");
        assertEquals(20, state.getGold(), "Gold should not change when revival fails");
    }

    /**
     * Inn: Revive on a living hero returns an error and does not charge gold.
     */
    @Test
    void innRevive_onLivingHero_returnsError() {
        state.setGold(100);
        String result = innService.reviveHero(state, warrior);

        assertTrue(result.contains("not defeated"),
                "Reviving a living hero should return an error message");
        assertEquals(100, state.getGold(), "Gold should not be charged for a failed revive");
    }
}
