package Tests;

import Classes.Heros.*;
import Classes.Party;
import Factory.HeroFactoryProvider;
import Observer.BattleEventBus;
import Observer.BattleObserver;
import Repository.DatabaseManager;
import Repository.PvPRepository;
import Repository.UserRepository;
import Strategy.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests validating the six design patterns required for Deliverable 2.
 *
 * Patterns covered:
 *   1. Singleton      — DatabaseManager, UserRepository, PvPRepository
 *   2. Factory Method — HeroFactoryProvider
 *   3. Strategy       — BattleAction implementations
 *   4. Observer       — BattleEventBus
 *   5. Repository     — (structural — covered in InnServiceTest / CampaignStateTest)
 *   6. State          — CampaignState (covered in CampaignStateTest)
 */
public class DesignPatternTest {

    private Party party1;
    private Party party2;
    private Warrior warrior;
    private Mage    mage;

    @BeforeEach
    void setUp() {
        warrior = new Warrior();
        mage    = new Mage();

        party1 = new Party("P1", "", "p1");
        party1.addHero(warrior);

        party2 = new Party("P2", "", "p2");
        party2.addHero(mage);

        BattleEventBus.getInstance().clearAll();
    }

    @AfterEach
    void tearDown() {
        BattleEventBus.getInstance().clearAll();
    }

    // ── PATTERN 1: Singleton ──────────────────────────────────────────────

    /**
     * UserRepository Singleton returns the exact same instance on repeated calls.
     */
    @Test
    void singleton_userRepository_sameInstanceEveryTime() {
        UserRepository a = UserRepository.getInstance();
        UserRepository b = UserRepository.getInstance();
        assertSame(a, b, "UserRepository.getInstance() must always return the same object");
    }

    /**
     * PvPRepository Singleton returns the exact same instance on repeated calls.
     */
    @Test
    void singleton_pvpRepository_sameInstanceEveryTime() {
        PvPRepository a = PvPRepository.getInstance();
        PvPRepository b = PvPRepository.getInstance();
        assertSame(a, b, "PvPRepository.getInstance() must always return the same object");
    }

    /**
     * BattleEventBus (also a Singleton) returns the same instance.
     */
    @Test
    void singleton_battleEventBus_sameInstanceEveryTime() {
        BattleEventBus a = BattleEventBus.getInstance();
        BattleEventBus b = BattleEventBus.getInstance();
        assertSame(a, b, "BattleEventBus.getInstance() must always return the same object");
    }

    // ── PATTERN 2: Factory Method ─────────────────────────────────────────

    /**
     * HeroFactoryProvider creates the correct concrete type for each HeroClass enum.
     */
    @Test
    void factory_createsCorrectHeroType_forEachClass() {
        Hero w = HeroFactoryProvider.create(HeroClass.WARRIOR);
        Hero m = HeroFactoryProvider.create(HeroClass.MAGE);
        Hero o = HeroFactoryProvider.create(HeroClass.ORDER);
        Hero c = HeroFactoryProvider.create(HeroClass.CHAOS);

        assertInstanceOf(Warrior.class, w, "WARRIOR class should produce a Warrior instance");
        assertInstanceOf(Mage.class,    m, "MAGE class should produce a Mage instance");
        assertInstanceOf(Order.class,   o, "ORDER class should produce an Order instance");
        assertInstanceOf(Chaos.class,   c, "CHAOS class should produce a Chaos instance");
    }

    /**
     * Each factory call produces a new, independent hero instance.
     */
    @Test
    void factory_eachCallProducesNewInstance() {
        Hero w1 = HeroFactoryProvider.create(HeroClass.WARRIOR);
        Hero w2 = HeroFactoryProvider.create(HeroClass.WARRIOR);
        assertNotSame(w1, w2, "Each factory call should return a distinct hero instance");
    }

    /**
     * Factory-created heroes start at level 1 with full HP and mana.
     */
    @Test
    void factory_heroStartsAtLevelOneWithFullStats() {
        Hero hero = HeroFactoryProvider.create(HeroClass.MAGE);
        assertEquals(1, hero.getLevel(),        "New hero should start at level 1");
        assertEquals(hero.getMaxHp(), hero.getHp(),     "New hero should start with full HP");
        assertEquals(hero.getMaxMana(), hero.getMana(), "New hero should start with full mana");
    }

    // ── PATTERN 3: Strategy ───────────────────────────────────────────────

    /**
     * AttackAction.execute() applies correct damage and returns a non-empty log string.
     */
    @Test
    void strategy_attackAction_dealsDamageAndReturnsLog() {
        int hpBefore = mage.getHp();
        AttackAction action = new AttackAction();
        String log = action.execute(warrior, mage, party1, party2);

        assertTrue(mage.getHp() < hpBefore, "Attack should reduce target HP");
        assertFalse(log.isBlank(),           "Attack log should not be blank");
        assertEquals("Attack", action.getName());
    }

    /**
     * DefendAction.execute() sets the defending flag on the actor.
     */
    @Test
    void strategy_defendAction_setsDefendingFlag() {
        assertFalse(warrior.isDefending(), "Warrior should not be defending before action");
        DefendAction action = new DefendAction();
        action.execute(warrior, null, party1, party2);
        assertTrue(warrior.isDefending(), "Warrior should be defending after DefendAction");
        assertEquals("Defend", action.getName());
    }

    /**
     * WaitAction.execute() restores 10 mana to the actor.
     */
    @Test
    void strategy_waitAction_restoresMana() {
        warrior.setMana(0);
        WaitAction action = new WaitAction();
        action.execute(warrior, null, party1, party2);
        assertEquals(10, warrior.getMana(), "Wait should restore 10 mana");
        assertEquals("Wait", action.getName());
    }

    /**
     * CastAction.execute() fails gracefully when actor has insufficient mana.
     */
    @Test
    void strategy_castAction_failsGracefullyWithLowMana() {
        warrior.setMana(0); // Berserker costs 60
        int hpBefore = mage.getHp();
        CastAction action = new CastAction();
        String log = action.execute(warrior, mage, party1, party2);

        assertEquals(hpBefore, mage.getHp(), "No damage should be dealt when cast fails");
        assertTrue(log.contains("Not enough mana"), "Log should indicate insufficient mana");
    }

    /**
     * Strategy implementations are interchangeable through the BattleAction interface.
     */
    @Test
    void strategy_allActionsImplementBattleActionInterface() {
        BattleAction[] strategies = {
                new AttackAction(),
                new DefendAction(),
                new CastAction(),
                new WaitAction()
        };
        for (BattleAction s : strategies) {
            assertNotNull(s.getName(), "getName() must return a non-null value for all strategies");
        }
    }

    // ── PATTERN 4: Observer ───────────────────────────────────────────────

    /**
     * Registered observers receive published events.
     */
    @Test
    void observer_subscribedObserver_receivesEvent() {
        List<String> received = new ArrayList<>();
        BattleObserver observer = (eventType, message) -> received.add(eventType + ":" + message);

        BattleEventBus bus = BattleEventBus.getInstance();
        bus.subscribe(observer);
        bus.publish("HP_CHANGED", "Warrior HP: 80/100");

        assertEquals(1, received.size(), "Observer should receive exactly 1 event");
        assertTrue(received.get(0).contains("HP_CHANGED"), "Event type should be HP_CHANGED");
        assertTrue(received.get(0).contains("Warrior"),    "Event message should include hero name");
    }

    /**
     * Unsubscribed observers no longer receive events.
     */
    @Test
    void observer_unsubscribedObserver_noLongerReceivesEvents() {
        List<String> received = new ArrayList<>();
        BattleObserver observer = (eventType, message) -> received.add(eventType);

        BattleEventBus bus = BattleEventBus.getInstance();
        bus.subscribe(observer);
        bus.unsubscribe(observer);
        bus.publish("BATTLE_OVER", "Alpha wins!");

        assertTrue(received.isEmpty(), "Unsubscribed observer should receive no events");
    }

    /**
     * Multiple observers all receive the same event.
     */
    @Test
    void observer_multipleObservers_allReceiveEvent() {
        List<String> log1 = new ArrayList<>();
        List<String> log2 = new ArrayList<>();

        BattleEventBus bus = BattleEventBus.getInstance();
        bus.subscribe((t, m) -> log1.add(t));
        bus.subscribe((t, m) -> log2.add(t));

        bus.publish("HERO_DEFEATED", "Mage has been defeated!");

        assertEquals(1, log1.size(), "First observer should receive the event");
        assertEquals(1, log2.size(), "Second observer should receive the event");
    }

    /**
     * clearAll() removes all observers so no one receives subsequent events.
     */
    @Test
    void observer_clearAll_removesAllObservers() {
        List<String> received = new ArrayList<>();
        BattleEventBus bus = BattleEventBus.getInstance();
        bus.subscribe((t, m) -> received.add(t));
        bus.clearAll();
        bus.publish("ABILITY_USED", "Fireball!");

        assertTrue(received.isEmpty(), "clearAll() should prevent any observer from receiving events");
    }

    /**
     * Subscribing the same observer twice does not result in duplicate event delivery.
     */
    @Test
    void observer_duplicateSubscription_eventDeliveredOnce() {
        List<String> received = new ArrayList<>();
        BattleObserver observer = (t, m) -> received.add(t);

        BattleEventBus bus = BattleEventBus.getInstance();
        bus.subscribe(observer);
        bus.subscribe(observer); // Duplicate — should be ignored
        bus.publish("BATTLE_STARTED", "Alpha vs Beta");

        assertEquals(1, received.size(),
                "Observer registered twice should still receive the event only once");
    }
}
