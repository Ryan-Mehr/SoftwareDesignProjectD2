package Tests;

import Classes.Heros.*;
import Factory.HeroFactoryProvider;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TC-09 — Hero levelling: XP thresholds, stat growth, and level cap.
 * Each hero class has unique stat increments; this verifies them all.
 */
public class HeroLevelUpTest {

    // ── TC-09: Warrior level-up stat growth ──────────────────────────────

    /**
     * TC-09 — Level up increments Warrior stats correctly.
     * Warrior: +3 ATK, +4 DEF, +5 HP, +2 MP per level.
     */
    @Test
    void tc09_warrior_statIncreasesOnLevelUp() {
        Warrior w = new Warrior();
        int atkL1 = w.getAttack();
        int defL1 = w.getDefense();
        int hpL1  = w.getMaxHp();
        int mpL1  = w.getMaxMana();

        w.setLevel(2);

        assertEquals(atkL1 + 3, w.getAttack(),   "Warrior ATK should increase by 3 per level");
        assertEquals(defL1 + 4, w.getDefense(),   "Warrior DEF should increase by 4 per level");
        assertEquals(hpL1  + 5, w.getMaxHp(),     "Warrior MaxHP should increase by 5 per level");
        assertEquals(mpL1  + 2, w.getMaxMana(),   "Warrior MaxMP should increase by 2 per level");
    }

    /**
     * TC-09b — Level up increments Mage stats correctly.
     * Mage: +2 ATK, +1 DEF, +5 HP, +7 MP per level.
     */
    @Test
    void tc09b_mage_statIncreasesOnLevelUp() {
        Mage m = new Mage();
        int atkL1 = m.getAttack();
        int mpL1  = m.getMaxMana();

        m.setLevel(2);

        assertEquals(atkL1 + 2, m.getAttack(),  "Mage ATK should increase by 2 per level");
        assertEquals(mpL1  + 7, m.getMaxMana(), "Mage MaxMP should increase by 7 per level");
    }

    /**
     * TC-09c — Order stat increments are correct.
     * Order: +1 ATK, +3 DEF, +5 HP, +7 MP per level.
     */
    @Test
    void tc09c_order_statIncreasesOnLevelUp() {
        Order o = new Order();
        int defL1 = o.getDefense();
        int mpL1  = o.getMaxMana();

        o.setLevel(2);

        assertEquals(defL1 + 3, o.getDefense(),  "Order DEF should increase by 3 per level");
        assertEquals(mpL1  + 7, o.getMaxMana(),  "Order MaxMP should increase by 7 per level");
    }

    /**
     * TC-09d — Chaos stat increments are correct.
     * Chaos: +4 ATK, +1 DEF, +10 HP, +2 MP per level.
     */
    @Test
    void tc09d_chaos_statIncreasesOnLevelUp() {
        Chaos c = new Chaos();
        int atkL1 = c.getAttack();
        int hpL1  = c.getMaxHp();

        c.setLevel(2);

        assertEquals(atkL1 + 4, c.getAttack(), "Chaos ATK should increase by 4 per level");
        assertEquals(hpL1 + 10, c.getMaxHp(),  "Chaos MaxHP should increase by 10 per level");
    }

    // ── Level cap ─────────────────────────────────────────────────────────

    /**
     * TC-09e — Hero level is capped at 20; calling setLevel(25) clamps to 20.
     */
    @Test
    void tc09e_levelCap_maxLevelIsEnforced() {
        Warrior w = new Warrior();
        w.setLevel(25);
        assertEquals(20, w.getLevel(),
                "Hero level must be capped at 20 even if setLevel() is called with a higher value");
    }

    /**
     * TC-09f — Stats at level 20 are consistent with incremental application.
     */
    @Test
    void tc09f_statsAtMaxLevel_consistentWithIncrements() {
        Warrior w = new Warrior();
        // Base: ATK=5, DEF=5; +3 ATK and +4 DEF per level; 19 increments (levels 2-20)
        int expectedAtk = 5 + 19 * 3;
        int expectedDef = 5 + 19 * 4;

        w.setLevel(20);

        assertEquals(expectedAtk, w.getAttack(),
                "Warrior ATK at level 20 should equal 5 + 19*3 = " + expectedAtk);
        assertEquals(expectedDef, w.getDefense(),
                "Warrior DEF at level 20 should equal 5 + 19*4 = " + expectedDef);
    }

    // ── Factory integration ───────────────────────────────────────────────

    /**
     * All hero classes created by the factory start at level 1.
     */
    @Test
    void allHeroClasses_startAtLevelOne() {
        for (HeroClass hc : HeroClass.values()) {
            Hero hero = HeroFactoryProvider.create(hc);
            assertEquals(1, hero.getLevel(),
                    hc + " should start at level 1");
            assertFalse(hero.isDefeated(),
                    hc + " should not be defeated when first created");
        }
    }
}
