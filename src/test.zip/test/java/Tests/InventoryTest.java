package Tests;

import Classes.Heros.Warrior;
import Classes.Inventory.Inventory;
import Classes.Inventory.Item;
import Classes.Inventory.ItemType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the Inventory and Item classes.
 * Covers item stacking, usage, and edge cases.
 */
public class InventoryTest {

    private Inventory inventory;
    private Warrior   warrior;

    @BeforeEach
    void setUp() {
        inventory = new Inventory();
        warrior   = new Warrior();
    }

    // ── Stacking ──────────────────────────────────────────────────────────

    @Test
    void addItem_startsEmpty_thenAddsCorrectly() {
        assertFalse(inventory.hasItem(ItemType.HEALTH_POTION),
                "Inventory should be empty initially");

        inventory.addItem(ItemType.HEALTH_POTION, 2);

        assertTrue(inventory.hasItem(ItemType.HEALTH_POTION),
                "Inventory should contain Health Potions after adding");
        assertEquals(2, inventory.getQuantity(ItemType.HEALTH_POTION),
                "Quantity should be 2 after adding 2");
    }

    @Test
    void addItem_stacksCorrectly() {
        inventory.addItem(ItemType.MANA_POTION, 1);
        inventory.addItem(ItemType.MANA_POTION, 3);
        assertEquals(4, inventory.getQuantity(ItemType.MANA_POTION),
                "Adding 1 then 3 of the same item should result in quantity 4");
    }

    @Test
    void addItem_differentTypesStoredIndependently() {
        inventory.addItem(ItemType.HEALTH_POTION, 2);
        inventory.addItem(ItemType.MANA_POTION,   3);

        assertEquals(2, inventory.getQuantity(ItemType.HEALTH_POTION));
        assertEquals(3, inventory.getQuantity(ItemType.MANA_POTION));
    }

    // ── Usage ─────────────────────────────────────────────────────────────

    @Test
    void useItem_healthPotion_restoresHp() {
        inventory.addItem(ItemType.HEALTH_POTION, 1);
        warrior.setHp(50);
        int hpBefore = warrior.getHp();

        boolean used = inventory.useItem(ItemType.HEALTH_POTION, warrior);

        assertTrue(used, "useItem() should return true on success");
        assertEquals(hpBefore + 50, Math.min(warrior.getHp(), warrior.getMaxHp()),
                "Health Potion should restore 50 HP");
        assertEquals(0, inventory.getQuantity(ItemType.HEALTH_POTION),
                "Quantity should decrease to 0 after use");
    }

    @Test
    void useItem_manaPotion_restoresMana() {
        inventory.addItem(ItemType.MANA_POTION, 1);
        warrior.setMana(10);

        inventory.useItem(ItemType.MANA_POTION, warrior);

        assertEquals(40, warrior.getMana(), "Mana Potion should restore 30 MP (10 + 30 = 40)");
    }

    @Test
    void useItem_elixir_fullyRestores() {
        inventory.addItem(ItemType.ELIXIR, 1);
        warrior.setHp(1);
        warrior.setMana(0);

        inventory.useItem(ItemType.ELIXIR, warrior);

        assertEquals(warrior.getMaxHp(),   warrior.getHp(),
                "Elixir should fully restore HP");
        assertEquals(warrior.getMaxMana(), warrior.getMana(),
                "Elixir should fully restore mana");
    }

    @Test
    void useItem_outOfStock_returnsFalse() {
        // Inventory is empty
        boolean used = inventory.useItem(ItemType.HEALTH_POTION, warrior);
        assertFalse(used, "useItem() should return false when item is not in inventory");
    }

    @Test
    void useItem_consumesOneAtATime() {
        inventory.addItem(ItemType.HEALTH_POTION, 3);
        warrior.setHp(50);

        inventory.useItem(ItemType.HEALTH_POTION, warrior);

        assertEquals(2, inventory.getQuantity(ItemType.HEALTH_POTION),
                "Using one potion should reduce quantity by 1, leaving 2");
    }

    // ── Item display ──────────────────────────────────────────────────────

    @Test
    void itemToString_includesNameAndQuantity() {
        inventory.addItem(ItemType.HEALTH_POTION, 5);
        boolean found = inventory.getAllItems().stream()
                .anyMatch(item -> item.toString().contains("Health Potion")
                        && item.toString().contains("5"));
        assertTrue(found, "Item toString should include display name and quantity");
    }

    // ── ItemType metadata ─────────────────────────────────────────────────

    @Test
    void itemType_costsAndDescriptionsAreSet() {
        assertEquals(30, ItemType.HEALTH_POTION.getCost(),  "Health Potion should cost 30 gold");
        assertEquals(25, ItemType.MANA_POTION.getCost(),    "Mana Potion should cost 25 gold");
        assertEquals(50, ItemType.ELIXIR.getCost(),         "Elixir should cost 50 gold");

        for (ItemType t : ItemType.values()) {
            assertFalse(t.getDisplayName().isBlank(),  t + " must have a display name");
            assertFalse(t.getDescription().isBlank(),  t + " must have a description");
        }
    }
}
