package Tests;

import Classes.Heros.*;
import Classes.Party;
import Strategy.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TC-03, TC-04, TC-05, TC-06, TC-07
 * Tests for core Hero combat mechanics and Strategy pattern actions.
 */
public class HeroCombatTest {

    // ── Shared fixtures ───────────────────────────────────────────────────
    private Warrior warrior;
    private Mage    mage;
    private Order   order;
    private Chaos   chaos;
    private Party   party1;
    private Party   party2;

    @BeforeEach
    void setUp() {
        warrior = new Warrior();
        mage    = new Mage();
        order   = new Order();
        chaos   = new Chaos();

        party1 = new Party("Alpha", "", "playerA");
        party1.addHero(warrior);
        party1.addHero(order);

        party2 = new Party("Beta", "", "playerB");
        party2.addHero(mage);
        party2.addHero(chaos);
    }

    // ── TC-03: Basic Attack ───────────────────────────────────────────────

    /**
     * TC-03 — Basic Attack: damage = max(1, attacker.ATK - target.DEF).
     *
     * Warrior (ATK=5, Lvl=1) attacks Mage (DEF=5, HP=100).
     * Expected: damage = max(1, 5-5) = 1. Mage HP = 99.
     */
    @Test
    void tc03_basicAttack_damageCalculation() {
        int mageHpBefore = mage.getHp();           // 100
        int expectedDamage = Math.max(1, warrior.getAttack() - mage.getDefense());

        AttackAction attack = new AttackAction();
        String log = attack.execute(warrior, mage, party1, party2);

        assertEquals(mageHpBefore - expectedDamage, mage.getHp(),
                "Mage HP should decrease by max(1, ATK - DEF)");
        assertTrue(log.contains("attacks"), "Log should describe the attack");
    }

    /**
     * TC-03b — Minimum damage is always 1 even when DEF >= ATK.
     */
    @Test
    void tc03b_basicAttack_minimumOneDamage() {
        // Give mage very high defense so raw damage would be negative
        mage.setLevel(10); // Defense grows with level
        int mageHpBefore = mage.getHp();

        // Force warrior to level 1 stats (already is, just be explicit)
        AttackAction attack = new AttackAction();
        attack.execute(warrior, mage, party1, party2);

        assertTrue(mage.getHp() < mageHpBefore,
                "Minimum 1 damage must always be dealt even when DEF >= ATK");
    }

    // ── TC-04: Warrior Berserker Attack ──────────────────────────────────

    /**
     * TC-04 — Berserker Attack hits primary target and up to 2 splash targets.
     *
     * Warrior (Mana ≥ 60) in a 1v3 scenario.
     * Expected: primary target takes full hit; up to 2 others take splash damage.
     */
    @Test
    void tc04_berserkerAttack_hitsMultipleTargets() {
        // Give warrior enough mana
        warrior.setMana(60);

        // Add a third enemy so splash can hit 2
        Order extraEnemy = new Order();
        party2.addHero(extraEnemy);

        int mageHpBefore  = mage.getHp();
        int chaosHpBefore = chaos.getHp();
        int extraHpBefore = extraEnemy.getHp();

        // Execute special ability
        warrior.useSpecialAbility(mage, party1, party2);

        // Primary target must have taken damage
        assertTrue(mage.getHp() < mageHpBefore,
                "Primary target (Mage) should take damage from Berserker Attack");

        // At least one additional enemy should have taken damage
        boolean splashOccurred = chaos.getHp() < chaosHpBefore
                || extraEnemy.getHp() < extraHpBefore;
        assertTrue(splashOccurred,
                "At least one additional enemy should take splash damage");
    }

    /**
     * TC-04b — Berserker Attack costs 60 mana; cannot fire when insufficient.
     */
    @Test
    void tc04b_berserkerAttack_requiresSufficientMana() {
        warrior.setMana(59); // One short
        assertFalse(warrior.canUseSpecialAbility(),
                "Berserker Attack should be unavailable with < 60 mana");

        warrior.setMana(60);
        assertTrue(warrior.canUseSpecialAbility(),
                "Berserker Attack should be available with exactly 60 mana");
    }

    /**
     * TC-04c — Berserker Attack deducts mana cost after use.
     */
    @Test
    void tc04c_berserkerAttack_deductsMana() {
        warrior.setMana(60);
        warrior.useSpecialAbility(mage, party1, party2);
        assertEquals(0, warrior.getMana(), "Warrior should have 0 mana after Berserker Attack");
    }

    // ── TC-05: Defend Action ─────────────────────────────────────────────

    /**
     * TC-05 — Defend reduces incoming damage by the hero's defense value.
     */
    @Test
    void tc05_defend_reducesDamage() {
        int orderHpBefore = order.getHp();
        int incomingRawDamage = 20;

        DefendAction defend = new DefendAction();
        defend.execute(order, null, party1, party2);
        assertTrue(order.isDefending(), "Order should be in defending state after Defend action");

        // Now apply incoming damage
        order.takeDamage(incomingRawDamage);

        // Damage while defending = max(0, raw - defense), minimum 1
        int expectedDamage = Math.max(1, incomingRawDamage - order.getDefense());
        assertEquals(orderHpBefore - expectedDamage, order.getHp(),
                "Damage while defending should be reduced by defense stat");
    }

    /**
     * TC-05b — Defend grants HP and mana regeneration at end of turn.
     */
    @Test
    void tc05b_defend_endOfTurnRegen() {
        // Reduce stats first so regen has room
        order.setHp(order.getMaxHp() - 20);
        order.setMana(order.getMaxMana() - 20);
        int hpBefore   = order.getHp();
        int manaBefore = order.getMana();

        order.defend(); // Set defending flag
        order.applyDefendEndOfTurn();

        assertEquals(hpBefore + 10, order.getHp(),
                "Defending hero should gain 10 HP at end of turn");
        assertEquals(manaBefore + 5, order.getMana(),
                "Defending hero should gain 5 mana at end of turn");
        assertFalse(order.isDefending(),
                "Defending flag should clear after applyDefendEndOfTurn()");
    }

    // ── TC-06: Wait Action ────────────────────────────────────────────────

    /**
     * TC-06 — Wait action recovers 10 mana.
     */
    @Test
    void tc06_wait_restoresMana() {
        warrior.setMana(20);
        int manaBefore = warrior.getMana();

        WaitAction wait = new WaitAction();
        String log = wait.execute(warrior, null, party1, party2);

        assertEquals(manaBefore + 10, warrior.getMana(),
                "Wait action should restore 10 mana");
        assertTrue(log.contains("wait"), "Log should mention waiting");
    }

    /**
     * TC-06b — Wait action does not exceed max mana.
     */
    @Test
    void tc06b_wait_manaCapRespected() {
        warrior.setMana(warrior.getMaxMana()); // Already full
        WaitAction wait = new WaitAction();
        wait.execute(warrior, null, party1, party2);
        assertEquals(warrior.getMaxMana(), warrior.getMana(),
                "Mana must not exceed maxMana after Wait");
    }

    // ── TC-07: Hero Defeat Detection ─────────────────────────────────────

    /**
     * TC-07 — Hero is marked defeated when HP reaches 0.
     */
    @Test
    void tc07_heroDeath_hpZeroSetsDefeated() {
        mage.takeDamage(mage.getHp() + 100); // Overkill damage

        assertEquals(0, mage.getHp(), "Defeated hero HP must be 0");
        assertTrue(mage.isDefeated(), "Hero should be marked defeated when HP reaches 0");
    }

    /**
     * TC-07b — Party defeat: hasAliveHeroes() returns false when all heroes are defeated.
     */
    @Test
    void tc07b_partyDefeat_allHeroesDown() {
        mage.takeDamage(9999);
        chaos.takeDamage(9999);

        assertFalse(party2.hasAliveHeroes(),
                "hasAliveHeroes() must return false when all heroes are defeated");
        assertEquals(0, party2.getAliveCount(),
                "getAliveCount() must return 0 when all heroes are defeated");
    }

    /**
     * TC-07c — Party still alive if at least one hero survives.
     */
    @Test
    void tc07c_partyAlive_oneHeroStanding() {
        mage.takeDamage(9999); // Defeated
        // chaos is still alive

        assertTrue(party2.hasAliveHeroes(),
                "Party should still be alive if any hero survives");
        assertEquals(1, party2.getAliveCount(),
                "getAliveCount() should return 1 when only one hero survives");
    }
}
