package Tests;

import Classes.Campaign.CampaignRoom;
import Classes.Campaign.CampaignState;
import Classes.Heros.Warrior;
import Classes.Heros.Mage;
import Classes.Party;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * TC-06 (room navigation), TC-07 (save/exit), TC-08 (load/continue), TC-11 (party cap)
 * Tests for the PvE CampaignState (State Pattern).
 */
public class CampaignStateTest {

    private CampaignState state;
    private Party         party;

    @BeforeEach
    void setUp() {
        party = new Party("Adventurers", "", "testUser");
        party.addHero(new Warrior());
        party.addHero(new Mage());
        state = new CampaignState("testUser", party);
    }

    // ── TC-06: Room navigation ────────────────────────────────────────────

    /**
     * TC-06 — advanceRoom() increments the room counter.
     */
    @Test
    void tc06_advanceRoom_incrementsCounter() {
        assertEquals(0, state.getCurrentRoom(), "Campaign should start at room 0");
        state.advanceRoom();
        assertEquals(1, state.getCurrentRoom(), "Room counter should increment to 1");
    }

    /**
     * TC-06b — Rooms 10, 20, and 30 are boss rooms.
     */
    @Test
    void tc06b_bossRoomsAtCorrectIntervals() {
        assertEquals(CampaignRoom.BOSS, state.getRoomType(10),  "Room 10 should be a BOSS room");
        assertEquals(CampaignRoom.BOSS, state.getRoomType(20),  "Room 20 should be a BOSS room");
        assertEquals(CampaignRoom.BOSS, state.getRoomType(30),  "Room 30 should be a BOSS room");
    }

    /**
     * TC-06c — Non-boss rooms are either BATTLE or INN (never BOSS).
     */
    @Test
    void tc06c_nonBossRoomsAreNotBoss() {
        for (int r : new int[]{1, 5, 9, 11, 15, 19, 21, 25, 29}) {
            CampaignRoom type = state.getRoomType(r);
            assertNotEquals(CampaignRoom.BOSS, type,
                    "Room " + r + " should not be a BOSS room");
            assertTrue(type == CampaignRoom.BATTLE || type == CampaignRoom.INN,
                    "Non-boss rooms must be BATTLE or INN");
        }
    }

    /**
     * TC-06d — advanceRoom() returns null once the campaign is completed.
     */
    @Test
    void tc06d_advanceRoom_returnsNullAfterCompletion() {
        state.setCurrentRoom(30);
        state.complete();
        assertNull(state.advanceRoom(),
                "advanceRoom() should return null when campaign is completed");
    }

    // ── TC-07: Campaign save / exit state ─────────────────────────────────

    /**
     * TC-07 — CampaignState preserves room number, gold, and party after creation.
     */
    @Test
    void tc07_campaignState_preservesFields() {
        state.setCurrentRoom(14);
        state.setGold(120);
        state.setStatus("ACTIVE");

        assertEquals(14,       state.getCurrentRoom(), "Room number should be preserved");
        assertEquals(120,      state.getGold(),        "Gold should be preserved");
        assertEquals("ACTIVE", state.getStatus(),      "Status should be preserved");
        assertEquals(party,    state.getActiveParty(), "Active party should be preserved");
    }

    /**
     * TC-07b — Completing the campaign sets status to COMPLETED.
     */
    @Test
    void tc07b_complete_setsStatusCompleted() {
        state.complete();
        assertEquals("COMPLETED", state.getStatus(),
                "Status should be COMPLETED after calling complete()");
        assertTrue(state.isCompleted(), "isCompleted() should return true");
    }

    // ── TC-08: Campaign load / continue ──────────────────────────────────

    /**
     * TC-08 — Restoring room progress simulates loading a saved campaign.
     * (CampaignState acts as the in-memory representation of a saved campaign.)
     */
    @Test
    void tc08_loadCampaign_restoresRoomAndGold() {
        // Simulate saving (room 18, gold 200)
        state.setCurrentRoom(18);
        state.setGold(200);

        // Simulate a fresh load by reading the same state object
        assertEquals(18,  state.getCurrentRoom(), "Loaded campaign should resume at room 18");
        assertEquals(200, state.getGold(),         "Loaded campaign should restore gold to 200");
        assertFalse(state.isCompleted(),            "Loaded campaign should not be marked completed");
    }

    // ── TC-09: Score calculation ──────────────────────────────────────────

    /**
     * TC-09 — calculateScore() is non-negative and increases with alive heroes.
     */
    @Test
    void tc09_calculateScore_positiveAndScalesWithAliveHeroes() {
        state.setCurrentRoom(15);
        state.setGold(80);

        int score = state.calculateScore();
        assertTrue(score > 0, "Score should be positive");

        // Kill one hero and check score drops
        party.getHeroes().get(0).takeDamage(9999);
        int lowerScore = state.calculateScore();
        assertTrue(lowerScore < score,
                "Score should decrease when fewer heroes are alive");
    }

    /**
     * TC-09b — onBattleWon accumulates gold and score.
     */
    @Test
    void tc09b_onBattleWon_accumulatesRewards() {
        int goldBefore  = state.getGold();
        int scoreBefore = state.getScore();

        state.onBattleWon(30, 50);

        assertEquals(goldBefore  + 30, state.getGold(),  "Gold should increase by battle reward");
        assertEquals(scoreBefore + 50, state.getScore(), "Score should increase by battle reward");
    }
}
